1、下载安装JDK（JRE被包含安装）
2、配置环境变量
3、下载安装使用Eclipse或IDEA等