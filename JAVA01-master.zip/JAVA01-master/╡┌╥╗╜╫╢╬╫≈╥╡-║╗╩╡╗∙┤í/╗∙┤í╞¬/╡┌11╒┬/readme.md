一、使用字节流读写文本文件
二、使用字符流读写数据

1、使用字节流类FileInputStream 读文本文件
InputStream 抽象类的常用子类 FileInputStream ,称为文件输入流 ，将文件中的数据输入到内存中，用于读取文本文件中的数据。

主要步骤：

1、导入相关类，并抛出异常

2、构造一个文件输入流对象，将文件输入流对象 (fileInputStream )与源数据源（E:\\obge\\obgeTest.txt)关联起来

　　注意：要在路径 E:\\obge\\obgeTest.txt 下弄点数据，如帅气的obge

3、利用文件输入流类的方法读取文本中的文件内容

4、关闭流

代码：

 package com.obge.test2;

import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamStu {
    public static void main(String[] args) throws IOException {
        //BufferedReader bufferedReader = new BufferedReader("E:\\obge\\obgeTest.txt");
        //创建流对象
        FileInputStream fileInputStream = new FileInputStream("E:\\obge\\obgeTest.txt");
        int data;
        //available()   可读取的字节数
        System.out.println("可读取的字节数："+fileInputStream.available());
        System.out.println("文件内容为：");
        //循环读取内容
        while((data = fileInputStream.read())!= -1){
            System.out.println(data +"");
        }
        //关闭流对象
        fileInputStream.close();
    }

}

2、使用字节流类FileOutStream 写文本文件
OutStream 抽象类的常用子类 FileOutStream ，称为文件输出流，用于把文件中的数据输出到文件中，就是把内存中的数据写到指定的文本文件中。

主要步骤：

1、导入相关类，并抛出异常

2、构造一个文件输出流对象，将文件输出流对象 (fileOutPutStream)与源数据源（E:\\obge\\obgeTest.txt)关联起来

　　注意：当obge 文件下没有 obgeTest.txt 这个文件时，会先创建此文件然后在写数据，有 obgeTest.txt 这个文件的话，默认情况下会覆盖原有文件中的内容，第二个参数 true 的作用就是像文件末尾中添加数据，

3、利用文件输出流类的方法将数据写入到文本文件中

4、关闭流

代码：

package com.obge.test2;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutPutStreamstu {

    public static void main(String[] args) {
        try {
            String str = "obge帅";
            //放到字节数组里
            byte[] words = str.getBytes();
            //创建流对象，当obge 文件下没有 obgeTest.txt 这个文件时，会先创建此文件然后在写数据。
            //如果obge 文件下有 obgeTest.txt 这个文件，默认情况下会覆盖原有文件中的内容，第二个参数 true 的作用就是像文件末尾中添加数据
            FileOutputStream fileOutPutStream = new FileOutputStream("E:\\obge\\obgeTest.txt",true);
            //写入文件
            fileOutPutStream.write(words,0,words.length);
            System.out.println("文件已更新");
            //关闭流
            fileOutPutStream.close();

        }catch (IOException e){
            System.out.println("文件创建出错"+e.getMessage());
        }

    }