public class Test {  
    public static void main (String []args)  
    {  
        System.out.println("90 度的正弦值：" + Math.sin(Math.PI/2));  
        System.out.println("0度的余弦值：" + Math.cos(0));  
        System.out.println("60度的正切值：" + Math.tan(Math.PI/3));  
        System.out.println("1的反正切值： " + Math.atan(1));  
        System.out.println("π/2的角度值：" + Math.toDegrees(Math.PI/2));  
        System.out.println(Math.PI);  
    }  
}
1	xxxValue()
	将 Number 对象转换为xxx数据类型的值并返回。
2	compareTo()
	将number对象与参数比较。
3	equals()
	判断number对象是否与参数相等。
4	valueOf()
	返回一个 Number 对象指定的内置数据类型
5	toString()
	以字符串形式返回值。
6	parseInt()
	将字符串解析为int类型。
7	abs()
	返回参数的绝对值。
8	ceil()
	返回大于等于( >= )给定参数的的最小整数，类型为双精度浮点型。
9	floor()
	返回小于等于（<=）给定参数的最大整数 。
10	rint()
	返回与参数最接近的整数。返回类型为double。
11	round()
	它表示四舍五入，算法为 Math.floor(x+0.5)，即将原来的数字加上 0.5 后再向下取整，所以，Math.round(11.5) 的结果为12，Math.round(-11.5) 的结果为-11。
12	min()
	返回两个参数中的最小值。
13	max()
	返回两个参数中的最大值。
14	exp()
	返回自然数底数e的参数次方。
15	log()
	返回参数的自然数底数的对数值。
16	pow()
	返回第一个参数的第二个参数次方。
17	sqrt()
	求参数的算术平方根。
18	sin()
	求指定double类型参数的正弦值。
19	cos()
	求指定double类型参数的余弦值。
20	tan()
	求指定double类型参数的正切值。
21	asin()
	求指定double类型参数的反正弦值。
22	acos()
	求指定double类型参数的反余弦值。
23	atan()
	求指定double类型参数的反正切值。
24	atan2()
	将笛卡尔坐标转换为极坐标，并返回极坐标的角度值。
25	toDegrees()
	将参数转化为角度。
26	toRadians()
	将角度转换为弧度。
27	random()
	返回一个随机数。
Java 中 int 和 Integer 的区别

1. int 是基本数据类型，int 变量存储的是数值。Integer 是引用类型，实际是一个对象，Integer 存储的是引用对象的地址。

2.

Integer i = new Integer(100);
Integer j = new Integer(100);
System.out.print(i == j); //false
因为 new 生成的是两个对象，其内存地址不同。

3.

int 和 Integer 所占内存比较：

Integer 对象会占用更多的内存。Integer 是一个对象，需要存储对象的元数据。但是 int 是一个原始类型的数据，所以占用的空间更少。

4. 非 new 生成的 Integer 变量与 new Integer() 生成的变量比较，结果为 false。

/**
 * 比较非new生成的Integer变量与new生成的Integer变量
 */
public class Test {
    public static void main(String[] args) {
        Integer i= new Integer(200);
        Integer j = 200;
        System.out.print(i == j);
        //输出：false
    }
}
因为非 new 生成的 Integer 变量指向的是 java 常量池中的对象，而 new Integer() 生成的变量指向堆中新建的对象，两者在内存中的地址不同。所以输出为 false。

5. 两个非 new 生成的 Integer 对象进行比较，如果两个变量的值在区间 [-128,127] 之间，比较结果为 true；否则，结果为 false。

/**
 * 比较两个非new生成的Integer变量
 */
public class Test {
    public static void main(String[] args) {
        Integer i1 = 127;
        Integer ji = 127;
        System.out.println(i1 == ji);//输出：true
        Integer i2 = 128;
        Integer j2 = 128;
        System.out.println(i2 == j2);//输出：false
    }
}
java 在编译 Integer i1 = 127 时，会翻译成 Integer i1 = Integer.valueOf(127)。

6. Integer 变量(无论是否是 new 生成的)与 int 变量比较，只要两个变量的值是相等的，结果都为 true。

/**
 * 比较Integer变量与int变量
 */
public class Test {
    public static void main(String[] args) {
        Integer i1 = 200;
        Integer i2 = new Integer(200);
        int j = 200;
        System.out.println(i1 == j);//输出：true
        System.out.println(i2 == j);//输出：true
    }
}
包装类 Integer 变量在与基本数据类型 int 变量比较时，Integer 会自动拆包装为 int，然后进行比较，实际上就是两个 int 变量进行比较，值相等，所以为 true。
\t	在文中该处插入一个tab键
\b	在文中该处插入一个后退键
\n	在文中该处换行
\r	在文中该处插入回车
\f	在文中该处插入换页符
\'	在文中该处插入单引号
\"	在文中该处插入双引号
\\	在文中该处插入反斜杠

Character ch = new Character('a');

提取字符中的大小写字母：

public class UpperLowerCase {
    public static void main(String []args) {
        String StrA="I am Tom.I am from China.";
        String StrB="";
        String StrC="";
        for(int i=0;i<StrA.length();i++){
            if(Character.isUpperCase(StrA.charAt(i)))
                StrB +=StrA.charAt(i)+"  ";
            if(Character.isLowerCase(StrA.charAt(i)))
                StrC +=StrA.charAt(i)+"  ";
            }
        System.out.println("字符串中大写字母有："+StrB);
        System.out.println("字符串中小写字母有："+StrC);
    }
}
输出结果为：

字符串中大写字母有：I  T  I  C  
字符串中小写字母有：a  m  o  m  a  m  f  r  o  m  h  i  n  a  

用构造函数创建字符串：

String str2=new String("Ruxury");
String 创建的字符串存储在公共池中，而 new 创建的字符串对象在堆上：

String s1 = "Ruxury";              // String 直接创建
String s2 = "Ruxury";              // String 直接创建
String s3 = s1;                    // 相同引用
String s4 = new String("Ruxury");   // String 对象创建
String s5 = new String("Ruxury");   // String 对象创建