	• 变量类型
		○ 基本数据类型
			§ 数值型
				□ 整数类型
				□ 浮点类型
			§ 字符型
			§ 布尔型
		○ 引用数据类型
			§ 类
			§ 接口
			§ 数组
	• 变量名
	• 变量值：
		○ 八进制：023 056（0开头）
		○ 十六进制：0x1357，0X3c（0x开头）、0x1abcL（长整型字面值表示方法，小写l也可以）
		○ 十进制

变量的初始化：定义变量的同时给变量赋值。
浮点型字面值
double类型：123.43 （默认无后缀直接double） 123.43d  123.43D
float类型：23.4f 23.4F

类定义的变量又叫对象


如果字面值超出char类型（char ch1=(char)65536;） 强转
Unicode编码
Char c = '\u005d';



科学计数法默认为double类型！！！

常量：
	在变量定义的前面加final
	字面值和final定义的常量统称为常量。
	
 num2=++num1；先自加1 再赋值
 num2=num1++ 先赋值，再自加1
package com.imooc;

public class VarDemo {
	public static void main(String[] args) {
		//定义两个整型变量x,y
		int x =2 , y = 3;
		System.out.println(x);
		System.out.println(y);
		System.out.print(x+"+"+y+"="+(x+y)+"\n");
		System.out.print(x+y+'\n'+"\n");//前者相当于值，后者为换行
		System.out.print(x+y+""+'\n');//5换行，相当于"\n"；
		System.out.print(x+y+'\t'+""+'\n'+'\n');
		System.out.print(x+'\t'+y+"\n");//加单引号，字符本身是一个整型，这里把字符都转化为整数了进行加法运算（\t表示一个整数9，整型之间相加减）
															//此处为字符（加法）运算
		System.out.print(x+"\t"+y+'\n');//加双引号，表示由一个字符组成的字符串。此处为字符串连接
		System.out.print(""+x+'\t'+y);//或者在最前面加一个空串，相当于一开始就做字符串连接
		//System.out.println();//换行
		System.out.print("\n\'"+x+"\'");
		System.out.println("\n'"+x+"'");
		//定义一个汉字的字符
		char ch='帝';
		System.out.println(ch);
		char 李='帝';//不建议中文作为变量名
		System.out.println(李);
		String 李1="大帝";
		System.out.println(李1);
		//用科学计数法表示浮点型数据
		double d=1.23E5;
		float f=1.23e5f;
		double d1=.2;
		System.out.println("d="+d);
		System.out.println("f="+f);
		System.out.println("d1="+d1);
	}
}
package com.imooc;

public class FinalDemo {
	public static void main(String[] args) {
		int m=5;
		final int n=6;
		m=10;
		final double PI=3.14;
		final double MIN_VALUE=0;
		System.out.println(n);
	}
}


