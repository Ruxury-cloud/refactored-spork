名词解释：
1、检查性异常: 不处理编译不能通过
2、非检查性异常:不处理编译可以通过，如果有抛出直接抛到控制台
3、运行时异常: 就是非检查性异常
4、非运行时异常: 就是检查性异常

异常使用可遵循下面的原则：
1：在当前方法被覆盖时，覆盖他的方法必须抛出相同的异常或异常的子类；
2：在当前方法声明中使用try-catch语句捕获异常；
3：如果父类抛出多个异常，则覆盖方法必须抛出那些异常的一个子集，不能抛出新异常。

Java 语言定义了一些异常类在 java.lang 标准包中。标准运行时异常类的子类是最常见的异常类。由于 java.lang 包是默认加载到所有的 Java 程序的，所以大部分从运行时异常类继承而来的异常都可以直接使用。

/**
 * 异常:
 * finally不一定被执行，，例如 catch 块中有退出系统的语句 System.exit(-1); finally就不会被执行
 *
 */
import java.io.*;
public class Demo {

    /**
     * @param args
     */
    public static void main(String[] args) {
        
        //检查异常1.打开文件
        FileReader fr=null;
        try {
            fr=new FileReader("d:\\aa.text");
            // 在出现异常的地方，下面的代码的就不执行
            System.out.println("aaa");
        } catch (Exception e) {
            System.out.println("进入catch");
            // 文档读取异常
            // System.exit(-1);
            System.out.println("message="+e.getLocalizedMessage());  //没有报哪一行出错
            e.printStackTrace();   // 打印出错异常还出现可以报出错先异常的行
        }
        // 这个语句块不管发生没有发生异常，都会执行
        // 一般来说，把需要关闭的资源，文件，连接，内存等
        finally
        {
            System.out.println("进入finally");
            if(fr!=null);
            {
                try {
                    fr.close();
                } catch (Exception e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }
            }
        }
        System.out.println("OK");
    }
}