Java 使用包（package）这种机制是为了防止命名冲突，访问控制，提供搜索和定位类、接口、枚举和注释等。

包语句的语法格式为：

package pkg1[．pkg2[．pkg3…]];

Java 中带包（创建及引用）的类的编译

只有一个文件时编译：

javac A.java
一个包的文件都在时编译：

javac -d . *.java
运行：编译之后会自己生成文件夹，不要进入这个文件夹，直接运行 java -cp /home/test test.Run，其中源文件在 test 文件夹中，包名为 test，启动文件为 Run.java。