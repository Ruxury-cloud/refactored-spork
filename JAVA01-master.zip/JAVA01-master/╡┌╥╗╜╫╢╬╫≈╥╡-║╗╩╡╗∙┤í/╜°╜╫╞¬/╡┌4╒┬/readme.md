## 第四章 高级文件处理

### 第一节 XML处理

#### 1、XML基本概念

- 可扩展标记语言：意义+数据
- 标签可自行定义，具有自我描述性
- 纯文本表示，跨系统/平台/语言

#### 2、XML结构

- 任何的起始标签都必须有一个结束标签
- 简化写法，例如，可以写为
- 大小写敏感，如和不一样
- 每一个文件都要有一个根元素
- 所有的特性都必须有值，且在值的周围加上引号
- 需要转义字符，如"<"需要用& l t代替

#### 3、XML扩展

- DTD(Document Type Definition)

  - ```
    <!DOCTYPE note[
            <!ELEMENT note (to,from,heading,body)>
            <!ELEMENT to   (#PCDATA)>
            <!ELEMENT from (#PCDATA)>
            <!ELEMENT heading(#PCDATA)>
            <!ELEMENT body (#PCDATA)>
        ]>
    ```

- XML Schema(XSD,XML Schema Definition)

  —定义XML文档的结构，DTD的继任者

  —支持数据类型，可扩展，功能更完善、强大

  —采用XML编写

- XSL

  —扩展样式表语言(eXtensible Stylesheet Language)

  —XSL作用于XML，等同于CSS作用于HTML

  —XSLT：转换XML文档

  —XPath：在XML文档中导航

  —XSL-FO：格式化XML文档

### 第二节 XML解析（DOM方法）

#### 1、XML解析

- XML解析方法

  —树结构

  ​    —DOM：Document Object Model文档对象模型，擅长（小规模）读/写

  —流结构

  ​    —SAX：Simple API for XML流机制解释器(推模式)，擅长读

  ​    —Stax：The Streaming API for XML流机制解释器(拉模式)，擅长读，JDK6引入

#### 2、DOM

- DOM是W3C处理XML的标准API

  —其处理方式是将XML整个作为类似树结构的方式读入内存中以便操作及解析，方便修改。

  —解析大数据量的XML文件，会遇到内存泄露及程序崩溃的风险。

#### 3、DOM类

- DocumentBuilder解析类，parse方法

- Node节点主接口，getChildNodes返回一个NodeList

- NodeList节点列表，每一个元素是一个Node

- Document文档根节点

- Element标签节点元素（每一个标签都是标签节点）

- Text节点（包含在XML元素内的，都算Text节点）

- Attr节点（每个属性节点）

- ```
   public static void recursiveTraverse()//自上而下进行访问
      {
      	try 
      	{
      		//采用Dom解析xml文件
              DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
              DocumentBuilder db = dbf.newDocumentBuilder();
              Document document = db.parse("users.xml");
              
              //获取所有的一级子节点
              NodeList usersList = document.getChildNodes();
              System.out.println(usersList.getLength());  //1  
              
              for (int i = 0; i < usersList.getLength(); i++) 
              {
                  Node users = usersList.item(i);         //1  users 
                  
                  NodeList userList = users.getChildNodes(); //获取二级子节点user的列表
                  System.out.println("==" + userList.getLength()); //9
                  
                  for (int j = 0; j < userList.getLength(); j++) //9
                  {
                      Node user = userList.item(j);
                      if (user.getNodeType() == Node.ELEMENT_NODE)
                      {
                      	 NodeList metaList = user.getChildNodes();
                           System.out.println("====" + metaList.getLength()); //7
                           
                           for (int k = 0; k < metaList.getLength(); k++) //7
                           {
                           	//到最后一级文本
                          	Node meta = metaList.item(k);
                          	if (meta.getNodeType() == Node.ELEMENT_NODE)
                          	{
                          		System.out.println(metaList.item(k).getNodeName() 
                          				+ ":" + metaList.item(k).getTextContent());
                          	}                                                              
                           }                    
                           System.out.println();
                      }                   
                  }
              }            
          } catch (Exception e) {
              e.printStackTrace();
          } 
      }   
  ```




#### 4、SAX

- Simple API for XML

  —SAX对XML文档的解析为一次性读取，不创建\不存储文档对象，很难同时访问文档中的多处数据

  —推模型。当它每发现一个节点就引发一个事件，而我们需要编写这些事件的处理程序。关键类：DefaultHandler

  —采用时间/流模型来解析XML文档，更快速、更轻量

  —有选择的解析和访问，不像DOM加载整个文档，内存要求较低

```
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class SAXReader {
	public static void main(String[] args) throws SAXException, IOException {
		XMLReader parser = XMLReaderFactory.createXMLReader();
		BookHandler bookHandler = new BookHandler();
		parser.setContentHandler(bookHandler);
		parser.parse("books.xml");//碰到.xml的文件会自动调用下面的方法
		System.out.println(bookHandler.getNameList());
	}
}

class BookHandler extends DefaultHandler {
	private List<String> nameList;
	private boolean title = false;

	public List<String> getNameList() {
		return nameList;
	}

	// xml文档加载时
	public void startDocument() throws SAXException {
		System.out.println("Start parsing document...");
		nameList = new ArrayList<String>();
	}

	// 文档解析结束
	public void endDocument() throws SAXException {
		System.out.println("End");
	}

	// 访问某一个元素
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {

		if (qName.equals("title")) {
			title = true;
		}
	}
	// 结束访问元素
	public void endElement(String namespaceURI, String localName, String qName) throws SAXException {
		// End of processing current element
		if (title) {
			title = false;
		}
	}
	// 访问元素正文
	public void characters(char[] ch, int start, int length) {
		if (title) {
			String bookTitle = new String(ch, start, length);//形参ch字符组就是标签元素的内容，位于开始标签和结束标签之间。在本例中，即为<title></title>之间的文本
			System.out.println("Book title: " + bookTitle);
			nameList.add(bookTitle);
		}
	}
}
```

#### 5、Stax

- SAX的五个回调方法：

  —startDocument 文档开始解析

  —endDocument 文档结束解析

  —startElement 开始访问元素

  —endElement 结束访问元素

  —characters 访问元素正文
- Streaming API for XML

  —流模型中的拉模型

  —在遍历文档时，会把感兴趣的部分从读取器中拉出，不需要引发事件，允许我们选择性地处理节点。这大大提高了灵活性，以及整体效率

  —基于指针的API，XMLStreamReader

  —基于迭代器的API，XMLEventReader

```
public class StaxReader {
	
	public static void main(String[] args) {
		StaxReader.readByStream();
		StaxReader.readByEvent();
	}

	//流模式
	public static void readByStream() {
		String xmlFile = "books.xml";
		XMLInputFactory factory = XMLInputFactory.newFactory();
		XMLStreamReader streamReader = null;
		try {
			streamReader = factory.createXMLStreamReader(new FileReader(xmlFile));			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (XMLStreamException e) {
			e.printStackTrace();
		}
		
		// 基于指针遍历
		try {
			while (streamReader.hasNext()) {
				int event = streamReader.next();
				// 如果是元素的开始
				if (event == XMLStreamConstants.START_ELEMENT) {
					// 列出所有书籍名称
					if ("title".equalsIgnoreCase(streamReader.getLocalName())) {
						System.out.println("title:" + streamReader.getElementText());
					}
				}
			}
			streamReader.close();
		} catch (XMLStreamException e) {
			e.printStackTrace();
		}
	}
	// 事件模式
	public static void readByEvent() {
		String xmlFile = "books.xml";
		XMLInputFactory factory = XMLInputFactory.newInstance();
		boolean titleFlag = false;
		try {
			// 创建基于迭代器的事件读取器对象
			XMLEventReader eventReader = factory.createXMLEventReader(new FileReader(xmlFile));
			// 遍历Event迭代器
			while (eventReader.hasNext()) {
				XMLEvent event = eventReader.nextEvent();
				// 如果事件对象是元素的开始
				if (event.isStartElement()) {
					// 转换成开始元素事件对象
					StartElement start = event.asStartElement();
					// 打印元素标签的本地名称
					String name = start.getName().getLocalPart();
					//System.out.print(start.getName().getLocalPart());	
					if(name.equals("title"))
					{
						titleFlag = true;
						System.out.print("title:");
					}
					
					// 取得所有属性
					Iterator attrs = start.getAttributes();
					while (attrs.hasNext()) {
						// 打印所有属性信息
						Attribute attr = (Attribute) attrs.next();
						//System.out.print(":" + attr.getName().getLocalPart() + "=" + attr.getValue());
					}
					//System.out.println();
				}
				//如果是正文
				if(event.isCharacters())
				{
					String s = event.asCharacters().getData();
					if(null != s && s.trim().length()>0 && titleFlag)
					{
						System.out.println(s.trim());
					}					
				}
				//如果事件对象是元素的结束
				if(event.isEndElement())
				{
					EndElement end = event.asEndElement();
					String name = end.getName().getLocalPart();
					if(name.equals("title"))
					{
						titleFlag = false;
					}
				}
			}
			eventReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (XMLStreamException e) {
			e.printStackTrace();
		}
	}
}
```

#### 6、其他的第三方库

- DOM/SAX/Stax是JDK自带的解析功能
- 第三方库一般都包含DOM，SAX等多种方式解析，是对Java解析进行封装

### 第三节 JSON简介及解析

#### 1、JSON概念

- JSON

  —JavaScript Object Notation，JS对象表示法

  —是一种轻量级的数据交换格式

  —类似XML，更小、更快、更易解析

  —最早用于JavaScript中，容易解析，最后推广到全语言

  —尽管使用JavaScript语法，但是**独立于编程语言**

#### 2、JSONObject和JSONArray

- 名称/值对。如"firstName":"John"

  —SON对象:{"name":"Jo","email":"[a@b.com](mailto:a@b.com)"}

  —数据在键值对中

  —数据由逗号隔开

  —花括号保存对象
- JSON数组

  —方括号保存数组

  —[{"name":"Jo","email":"[a@b.com](mailto:a@b.com)"},{"name":"Jo","email":"[a@b.com](mailto:a@b.com)"}]

#### 3、Java的JSON处理

- org.json:JSON官方推荐的解析类

  —简单易用，通用性强

  —复杂功能欠缺

  ```
  import org.json.JSONArray;
  import org.json.JSONObject;
  import java.io.File;
  import java.io.FileReader;
  import java.util.ArrayList;
  import java.util.Arrays;
  import java.util.List;
  /**
   * 采用org.json包来解析JSON
   * @author Tom
   *
   */
  
  public class OrgJsonTest {
  	public static void main(String[] args) {
  		testJsonObject();
  		System.out.println("=========华丽丽的分割线==============");
  		testJsonFile();
  	}
      public static void testJsonObject() {
      	//构造对象
      	Person p = new Person();
      	p.setName("Tom");
      	p.setAge(20);
      	p.setScores(Arrays.asList(60,70,80));
      	//构造JSONObject对象
      	JSONObject obj = new JSONObject(); 		
          //string
      	obj.put("name", p.getName());
          //int
      	obj.put("age", p.getAge());
          //array
          obj.put("scores", p.getScores());
          //null
          //object.put("null", null);
          System.out.println(obj);              
          System.out.println("name: " + obj.getString("name"));
          System.out.println("age: " + obj.getInt("age"));
          System.out.println("scores: " + obj.getJSONArray("scores"));
      }
      public static void testJsonFile() {
      	File file = new File("books.json");
          try (FileReader reader = new FileReader(file)) {
          	//读取文件内容到JsonObject对象中
              int fileLen = (int) file.length();
              char[] chars = new char[fileLen];
              reader.read(chars);
              String s = String.valueOf(chars);
              JSONObject jsonObject = new JSONObject(s);
              //开始解析JSONObject对象
              JSONArray books = jsonObject.getJSONArray("books");
              List<Book> bookList = new ArrayList<>();
              for (Object book : books) {
              	//获取单个JSONObject对象
                  JSONObject bookObject = (JSONObject) book;
                  Book book1 = new Book();
                  book1.setAuthor(bookObject.getString("author"));
                  book1.setYear(bookObject.getString("year"));
                  book1.setTitle(bookObject.getString("title"));
                  book1.setPrice(bookObject.getInt("price"));
                  book1.setCategory(bookObject.getString("category"));
                  bookList.add(book1);
              }
              
              for(Book book:bookList)
              {
              	System.out.println(book.getAuthor() + ",  " + book.getTitle());
              }
  
          } catch (Exception e) {
              e.printStackTrace();
          }
      }
  }
  ```

  

- GSON，Google出品

  ```
  import java.io.File;
  import java.io.FileReader;
  import java.util.Arrays;
  import java.util.List;
  import com.google.gson.Gson;
  import com.google.gson.JsonElement;
  import com.google.gson.JsonObject;
  import com.google.gson.reflect.TypeToken;
  /**
   * 采用Google GSON来处理JSON
   * @author Tom
   *
   */
  public class GsonTest {
  	public static void main(String[] args) {
  		testJsonObject();
  		System.out.println("=========华丽丽的分割线==============");
  		testJsonFile();
  	}
  	public static void testJsonObject() {
  		//构造对象
      	Person p = new Person();
      	p.setName("Tom");
      	p.setAge(20);
      	p.setScores(Arrays.asList(60,70,80));
      	//从Java对象到JSON字符串
  		Gson gson = new Gson();
  		String s = gson.toJson(p);
  		System.out.println(s); //{"name":"Tom","age":20,"scores":[60,70,80]}
  		//从JSON字符串到Java对象
  		Person p2 = gson.fromJson(s, Person.class);
  		System.out.println(p2.getName());  //Tom
  		System.out.println(p2.getAge());   //20
  		System.out.println(p2.getScores());//[60, 70, 80]
  		//调用GSON的JsonObject
  		JsonObject json = gson.toJsonTree(p).getAsJsonObject(); //将整个json解析为一颗树
  		System.out.println(json.get("name"));  //"Tom"
  		System.out.println(json.get("age"));   //20
  		System.out.println(json.get("scores"));//[60,70,80]	
  	}
  	public static void testJsonFile() {
  		Gson gson = new Gson();
  		File file = new File("books2.json");	
          try (FileReader reader = new FileReader(file)) {
          	List<Book> books = gson.fromJson(reader, new TypeToken<List<Book>>(){}.getType());    
          	for(Book book : books)
          	{
          		System.out.println(book.getAuthor() + ",  " + book.getTitle());
          	}
          } catch (Exception e) {
              e.printStackTrace();
          }
  	}
  }
  ```

  

- Jackson:号称最快的JSON处理器

  ```
  import java.util.HashMap;
  import java.util.List;
  import java.util.Map;
  
  import com.fasterxml.jackson.core.JsonProcessingException;
  import com.fasterxml.jackson.core.type.TypeReference;
  import com.fasterxml.jackson.databind.JsonNode;
  import com.fasterxml.jackson.databind.ObjectMapper;
  import com.google.gson.reflect.TypeToken;
  
  /**
   * 采用Jackson来处理JSON
   * @author Tom
   *
   */
  
  public class JacksonTest {
  
  	public static void main(String[] args) throws Exception {
  		testJsonObject();
  		System.out.println("=========华丽丽的分割线==============");
  		testJsonFile();
  	}
  	
  	static void testJsonObject() throws IOException {
  		ObjectMapper om = new ObjectMapper();
  		
  		//构造对象
      	Person p = new Person();
      	p.setName("Tom");
      	p.setAge(20);
      	p.setScores(Arrays.asList(60,70,80));
      	
      	//将对象解析为json字符串
  		String jsonStr = om.writeValueAsString(p);
  		System.out.println(jsonStr);
  		
  		//从json字符串重构对象
  		Person p2 = om.readValue(jsonStr, Person.class);
  		System.out.println(p2.getName());
  		System.out.println(p2.getAge());
  		System.out.println(p2.getScores());
  		
  		//从json字符串重构为JsonNode对象
  		JsonNode node = om.readTree(jsonStr);
  		System.out.println(node.get("name").asText());
  		System.out.println(node.get("age").asText());
  		System.out.println(node.get("scores"));		
  	}
  	
  	static void testJsonFile() throws IOException {
  		ObjectMapper om = new ObjectMapper();
  		
  		//从json文件中加载，并重构为java对象
  		File json2 = new File("books2.json");
  		List<Book> books = om.readValue(json2, new TypeReference<List<Book>>(){});
  		for (Book book : books) {
  			System.out.println(book.getAuthor());
  			System.out.println(book.getTitle());
  		}
  	}	
  }
  ```

  

#### 4、JSON主要用途

- JSON生成
- JSON解析
- JSON校验
- 和Java Bean对象进行互相解析

  —具有一个无参的构造函数

  —可以包括多个属性，所有属性都是private

  —每一个属性都有相应的Getter/Setter方法

  —Java Bean用于封装数据，又可成为POJO(Plain Old Java Object)

#### 5、JSON和XML比较

- 都是数据交换格式，可读性强，可扩展性高
- 大部分的情况下，JSON更具优势(编码简单，转换方便)，而且JSON字符长度一般小于XML，传输效率更高
- XML更加注重标签和顺序
- JSON会丢失信息
### 第四节 图形图像简介及解析

#### 1、图形图像基础概念

- 图形：

  —矢量图，根据几何特性来画的，比如点、直线、弧线等
- 图像：

  —由像素点组成

  —格式：jpg,png,bmp,svg,wmf,gif,tiff等

  —颜色：RGB(Red,Green,Blue)

#### 2、Java图形图像关键类

- 图形：Graph

  —java.awt包

  —Java 2D库：Graphics2D,Line2D,Rectangle2D,Ellipse2D,Arc2D

  —Color,Stroke
- 图像：Image

  —javax.imageio包

  —ImageIO，BufferedImage，ImageReader,ImageWriter

#### 3、Java图像关键类描述

- Java原生支持**jpg**,**png**,bmp,wbmp,gif
- javax.imageio.ImageIO

  —自动封装多种ImageReader和ImageWriter，读写图像文件

  —read读取图片write写图片
- java.awt.image.BufferedImage,图像在内存中的表示类

  —getHeight 获取高度

  —getWidth 获取宽度
- 图像文件读写/截取/合并

```
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

public class ImageTest {

	public static void main(String[] args) throws Exception {
		readAndWrite();
		readComparison();			
		cropImage("c:/temp/ecnu.jpg", "c:/temp/shida.jpg", 750, 250, 700, 300, "jpg", "jpg");
		combineImagesHorizontally("c:/temp/ecnu.jpg","c:/temp/ecnu.jpg","jpg", "c:/temp/ecnu2.jpg");
		combineImagesVertically("c:/temp/ecnu.jpg","c:/temp/ecnu.jpg","jpg", "c:/temp/ecnu3.jpg");
	}

	public static void readAndWrite() throws Exception {
		BufferedImage image = ImageIO.read(new File("c:/temp/ecnu.jpg"));
		System.out.println("Height: " + image.getHeight()); // 高度像素
		System.out.println("Width: " + image.getWidth()); // 宽度像素
		ImageIO.write(image, "png", new File("c:/temp/ecnu.png"));
	}

	public static void readComparison() throws Exception {
		System.out.println("===========加载速度测试==============");

		// ImageIO需要测试图片的类型，加载合适的ImageReader来读取图片，耗时更长
		long startTime = System.nanoTime();
		BufferedImage image = ImageIO.read(new File("c:/temp/ecnu.jpg"));
		System.out.println("Height: " + image.getHeight()); // 高度像素
		System.out.println("Width: " + image.getWidth()); // 宽度像素
		long endTime = System.nanoTime();
		System.out.println((endTime - startTime) / 1000000.0 + "毫秒");

		// 指定用jpg Reader来加载，速度会加快
		startTime = System.nanoTime();
		Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName("jpg");
		ImageReader reader = (ImageReader) readers.next();
		System.out.println(reader.getClass().getName());
		ImageInputStream iis = ImageIO.createImageInputStream(new File("c:/temp/ecnu.jpg"));
		reader.setInput(iis, true);
		System.out.println("Height:" + reader.getHeight(0));
		System.out.println("Width:" + reader.getWidth(0));
		endTime = System.nanoTime();
		System.out.println((endTime - startTime) / 1000000.0 + "毫秒");
	}

	/**
	 * cropImage 将原始图片文件切割一个矩形，并输出到目标图片文件
	 * @param fromPath 原始图片
	 * @param toPath  目标图片
	 * @param x       坐标起点x
	 * @param y       坐标起点y
	 * @param width   矩形宽度
	 * @param height  矩形高度
	 * @param readImageFormat  原始文件格式
	 * @param writeImageFormat 目标文件格式
	 * @throws Exception
	 */
	public static void cropImage(String fromPath, String toPath, int x, int y, int width, int height, String readImageFormat,
			String writeImageFormat) throws Exception {
		FileInputStream fis = null;
		ImageInputStream iis = null;
		try {
			// 读取原始图片文件
			fis = new FileInputStream(fromPath);
			Iterator<ImageReader> it = ImageIO.getImageReadersByFormatName(readImageFormat);
			ImageReader reader = it.next();			
			iis = ImageIO.createImageInputStream(fis);
			reader.setInput(iis, true);
			
			// 定义一个矩形 并放入切割参数中
			ImageReadParam param = reader.getDefaultReadParam();			
			Rectangle rect = new Rectangle(x, y, width, height);//x和y,分别是矩形起点（左上角顶点）的横坐标和纵坐标;width,矩形宽度;height,矩形高度			
			param.setSourceRegion(rect);
			
			//从源文件读取一个矩形大小的图像
			BufferedImage bi = reader.read(0, param);
			
			//写入到目标文件
			ImageIO.write(bi, writeImageFormat, new File(toPath));
		} finally {
			fis.close();
			iis.close();
		}
	}

	/**
     * 横向拼接两张图片，并写入到目标文件
     * 拼接的本质，就是申请一个大的新空间，然后将原始的图片像素点拷贝到新空间，最后保存
     * @param firstPath 第一张图片的路径
     * @param secondPath    第二张图片的路径
     * @param imageFormat   拼接生成图片的格式
     * @param toPath    目标图片的路径
     */
    public static void combineImagesHorizontally(String firstPath, String secondPath,String imageFormat, String toPath){  
        try {  
            //读取第一张图片    
            File  first  =  new  File(firstPath);    
            BufferedImage  imageOne = ImageIO.read(first);    
            int  width1  =  imageOne.getWidth();//图片宽度    
            int  height1  =  imageOne.getHeight();//图片高度    
            //从第一张图片中读取RGB    
            int[]  firstRGB  =  new  int[width1*height1];    
            firstRGB  =  imageOne.getRGB(0,0,width1,height1,firstRGB,0,width1);    

            //对第二张图片做同样的处理    
            File  second  =  new  File(secondPath);    
            BufferedImage  imageTwo  =  ImageIO.read(second); 
            int width2 = imageTwo.getWidth();
            int height2 = imageTwo.getHeight();
            int[]   secondRGB  =  new  int[width2*height2];    
            secondRGB  =  imageTwo.getRGB(0,0,width2,height2,secondRGB,0,width2);   
            

            //生成新图片
            int height3 = (height1>height2)?height1:height2; //挑选高度大的，作为目标文件的高度
            int width3  = width1 + width2;                   //宽度，两张图片相加
            BufferedImage  imageNew  =  new  BufferedImage(width3,height3,BufferedImage.TYPE_INT_RGB);    
            
            //设置左半部分的RGB 从(0,0) 开始 
            imageNew.setRGB(0,0,width1,height1,firstRGB,0,width1); 
            //设置右半部分的RGB 从(width1, 0) 开始 
            imageNew.setRGB(width1,0,width2,height2,secondRGB,0,width2);
               
            //保存图片
            ImageIO.write(imageNew,  imageFormat,  new  File(toPath));
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }

    /**
     * 纵向拼接图片（两张）
     * 拼接的本质，就是申请一个大的新空间，然后将原始的图片像素点拷贝到新空间，最后保存
     * @param firstPath 读取的第一张图片
     * @param secondPath    读取的第二张图片
     * @param imageFormat 图片写入格式
     * @param toPath    图片写入路径
     */
    public static void combineImagesVertically(String firstPath, String secondPath,String imageFormat, String toPath){  
        try {  
            //读取第一张图片    
            File  first  =  new  File(firstPath);    
            BufferedImage  imageOne = ImageIO.read(first);    
            int  width1  =  imageOne.getWidth();//图片宽度    
            int  height1  =  imageOne.getHeight();//图片高度    
            //从图片中读取RGB    
            int[]  firstRGB  =  new  int[width1*height1];    
            firstRGB  =  imageOne.getRGB(0,0,width1,height1,firstRGB,0,width1);    

            //对第二张图片做相同的处理    
            File  second  =  new  File(secondPath);    
            BufferedImage  imageTwo  =  ImageIO.read(second); 
            int width2 = imageTwo.getWidth();
            int height2 = imageTwo.getHeight();
            int[]   secondRGB  =  new  int[width2*height2];    
            secondRGB  =  imageTwo.getRGB(0,0,width2,height2,secondRGB,0,width2); 

            //生成新图片
            int width3 = (width1>width2)?width1:width2; //挑选宽度大的，作为目标文件的宽度
            int height3 = height1+height2;              //高度，两张图片相加
            BufferedImage  imageNew  =  new  BufferedImage(width3,height3,BufferedImage.TYPE_INT_RGB);    
            //设置上半部分的RGB 从(0,0) 开始 
            imageNew.setRGB(0,0,width1,height1,firstRGB,0,width1);
            //设置下半部分的RGB 从(0, height1) 开始 
            imageNew.setRGB(0,height1,width2,height2,secondRGB,0,width2);  
            //保存图片
            ImageIO.write(imageNew, imageFormat, new File(toPath));
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }
}
```

#### 4、验证码生成

```
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

public class ValidateCodeTest {
	//没有1 I L 0 o
	static char[] codeSequence = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'M', 'N', 'P', 'Q', 'R', 'S', 'T',
			'U', 'V', 'W', 'X', 'Y', 'Z', '2', '3', '4', '5', '6', '7', '8', '9' };
	static int charNum = codeSequence.length;
	
	public static void main(String[] a) throws IOException
	{
		generateCode("c:/temp/code.jpg");
	}	

	public static void generateCode(String filePath) throws IOException {
		// 首先定义验证码图片框  
		int width = 80; // 验证码图片的宽度
		int height = 32; // 验证码图片的高度
        BufferedImage buffImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB); 
        //定义图片上的图形和干扰线
        Graphics2D gd = buffImg.createGraphics();   
        gd.setColor(Color.LIGHT_GRAY);   // 将图像填充为浅灰色   
        gd.fillRect(0, 0, width, height);   
        gd.setColor(Color.BLACK);        // 画边框。   
        gd.drawRect(0, 0, width - 1, height - 1);   
        // 随机产生16条灰色干扰线，使图像中的认证码不易识别  
        gd.setColor(Color.gray); 
        // 创建一个随机数生成器类   用于随机产生干扰线
        Random random = new Random();   
        for (int i = 0; i < 16; i++) {   
            int x = random.nextInt(width);   
            int y = random.nextInt(height);   
            int xl = random.nextInt(12);   
            int yl = random.nextInt(12);   
            gd.drawLine(x, y, x + xl, y + yl);   
        }   
        
        
        //计算字的位置坐标
        int codeCount = 4; // 字符个数
    	int fontHeight; // 字体高度
    	int codeX; // 第一个字符的x坐标，因为后面的字符坐标依次递增，所以它们的x轴值是codeX的倍数
    	int codeY; // 验证字符的y坐标，因为并排所以值一样
    	// width-4 除去左右多余的位置，使验证码更加集中显示，减得越多越集中。
    	// codeCount+1 //等比分配显示的宽度，包括左右两边的空格
    	codeX = (width - 4) / (codeCount + 1); //第一个字母的起始位置    	
    	fontHeight = height - 10;  // height - 10 高度中间区域显示验证码
    	codeY = height - 7;	
        // 创建字体，字体的大小应该根据图片的高度来定。   
        Font font = new Font("Fixedsys", Font.PLAIN, fontHeight);           
        gd.setFont(font);   
        
        // 随机产生codeCount数字的验证码。   
        for (int i = 0; i < codeCount; i++) {   
            // 每次随机拿一个字母，赋予随机的颜色  
            String strRand = String.valueOf(codeSequence[random.nextInt(charNum)]);   
            int red = random.nextInt(255);   
            int green = random.nextInt(255);   
            int blue = random.nextInt(255);   
            gd.setColor(new Color(red,green,blue));   
            //把字放到图片上!!!
            gd.drawString(strRand, (i + 1) * codeX, codeY);              
        }   
        
        ImageIO.write(buffImg, "jpg", new File(filePath));             
	}
}
```

#### 5、统计图生成

- 统计图

  - 柱状图/饼图/折线图

  - Java原生的Graphics 2D可以画，比较繁琐

  - 基于jFreeChart


```
import java.awt.Font;
import java.io.File;
import java.io.IOException;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class JFreeChartTest {

	public static void main(String[] args) {
		writeBar("c:/temp/bar.jpg"); // 柱状图
		writePie("c:/temp/pie.jpg"); // 饼图
		writeLine("c:/temp/line.jpg");// 折线图
	}
	
	public static StandardChartTheme getChineseTheme()
	{
		StandardChartTheme chineseTheme = new StandardChartTheme("CN");
		chineseTheme.setExtraLargeFont(new Font("隶书", Font.BOLD, 20));
		chineseTheme.setRegularFont(new Font("宋书", Font.PLAIN, 15));
		chineseTheme.setLargeFont(new Font("宋书", Font.PLAIN, 15));
		return chineseTheme;
	}
	
	public static void writeBar(String fileName) {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		dataset.addValue(11, "", "第一季度");
		dataset.addValue(41, "", "第二季度");
		dataset.addValue(51, "", "第三季度");
		dataset.addValue(4, "", "第四季度");

		// PlotOrientation.HORIZONTAL横向 PlotOrientation.VERTICAL 竖向
		// 引入中文主题样式
		ChartFactory.setChartTheme(getChineseTheme());
		JFreeChart chart = ChartFactory.createBarChart3D("柱状图", "2018年", "产品总量", dataset, PlotOrientation.VERTICAL,
				false, false, false);

		try {
			ChartUtilities.saveChartAsJPEG(new File(fileName), chart, 600, 300);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void writePie(String fileName) {
		DefaultPieDataset pds = new DefaultPieDataset();
		pds.setValue("C人数", 100);
		pds.setValue("C++人数", 200);
		pds.setValue("Java人数", 300);
		try {
			ChartFactory.setChartTheme(getChineseTheme());
			JFreeChart chart = ChartFactory.createPieChart("饼图", pds);
			
			ChartUtilities.saveChartAsJPEG(new File(fileName), chart, 600, 300);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void writeLine(String fileName) {
		DefaultCategoryDataset lines = new DefaultCategoryDataset();
		//第一条线
		lines.addValue(100, "Java核心技术", "1月");
		lines.addValue(200, "Java核心技术", "2月");
		lines.addValue(400, "Java核心技术", "3月");
		lines.addValue(500, "Java核心技术", "4月");
		
		//第二条线
		lines.addValue(100, "Java核心技术(进阶)", "1月");
		lines.addValue(400, "Java核心技术(进阶)", "2月");
		lines.addValue(900, "Java核心技术(进阶)", "3月");
		try {
			ChartFactory.setChartTheme(getChineseTheme());
			JFreeChart chart = ChartFactory.createLineChart("折线图", "时间", "人数", lines);
			ChartUtilities.saveChartAsJPEG(new File(fileName), chart, 600, 300);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
```

### 第五节 条形码和二维码简介及解析

#### 1、条形码

- 条形码(barcode)

  —将宽度不等的多个黑条和空白，按照一定的编码规则排列，用以表达一组信息的图形标示符

  —上个世纪40年代发明的

  —通常代表一串数字/字母，每一位有特殊意义

  —一般数据容量30个数字/字母

  —专门机构管理:中国物品编码中心

#### 2、二维码

- 二维码，二维条形码

  —用某种特定的几何图形按照一定规律在平面（二维方向上）分布的黑白相间的图形记录数据符号信息

  —比一维条形码能存储更多的信息，表示更多的数据类型

  —能够存储数字/字母/汉字/图片等信息

  —字符集128个字符

  —可存储几百到几十kb字符

#### 3、Java识别二维码和条形码

- Zxing(Zebra Crossing)

  —BitMatrix位图矩阵

  —MultiFormatWriter位图编写器

  —MatrixToImageWriter写入图片

  ```
  import com.google.zxing.BarcodeFormat;
  import com.google.zxing.BinaryBitmap;
  import com.google.zxing.DecodeHintType;
  import com.google.zxing.EncodeHintType;
  import com.google.zxing.LuminanceSource;
  import com.google.zxing.MultiFormatReader;
  import com.google.zxing.MultiFormatWriter;
  import com.google.zxing.Result;
  import com.google.zxing.WriterException;
  import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
  import com.google.zxing.client.j2se.MatrixToImageWriter;
  import com.google.zxing.common.BitMatrix;
  import com.google.zxing.common.HybridBinarizer;
  
  import javax.imageio.ImageIO;
  
  import java.awt.image.BufferedImage;
  import java.io.ByteArrayOutputStream;
  import java.io.File;
  import java.io.FileOutputStream;
  import java.util.HashMap;
  import java.util.Map;
  
  public class BarCodeTest {
  	/**
  	 * generateCode 根据code生成相应的一维码
  	 * @param file 一维码目标文件
  	 * @param code 一维码内容
  	 * @param width 图片宽度
  	 * @param height 图片高度
  	 */
      public static void generateCode(File file, String code, int width, int height) {
      	//定义位图矩阵BitMatrix
          BitMatrix matrix = null;
          try {
              // 使用code_128格式进行编码生成100*25的条形码
          	MultiFormatWriter writer = new MultiFormatWriter();
          	
              matrix = writer.encode(code,BarcodeFormat.CODE_128, width, height, null);
              //matrix = writer.encode(code,BarcodeFormat.EAN_13, width, height, null);
          } catch (WriterException e) {
              e.printStackTrace();
          }
          
          //将位图矩阵BitMatrix保存为图片
          try (FileOutputStream outStream = new FileOutputStream(file)) {
              ImageIO.write(MatrixToImageWriter.toBufferedImage(matrix), "png",
                      outStream);
              outStream.flush();
          } catch (Exception e) {
          	e.printStackTrace();
          }
      }
      
      /**
       * readCode 读取一张一维码图片
       * @param file 一维码图片名字
       */
      public static void readCode(File file){
          try {
          	BufferedImage image = ImageIO.read(file);
              if (image == null) {
                  return;
              }
              LuminanceSource source = new BufferedImageLuminanceSource(image);
              BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
              
              Map<DecodeHintType, Object> hints = new HashMap<>();
              hints.put(DecodeHintType.CHARACTER_SET, "GBK");
              hints.put(DecodeHintType.PURE_BARCODE, Boolean.TRUE);
              hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
              
              Result result = new MultiFormatReader().decode(bitmap, hints);
              System.out.println("条形码内容: "+result.getText());
          } catch (Exception e) {
              e.printStackTrace();
          }
      }
  
      public static void main(String[] args) throws Exception {
          //generateCode(new File("1dcode.png"), "123456789012", 500, 250);
      	readCode(new File("1dcode.png"));
      }
  }
  ```


#### 4、Barcode4J

- 纯Java实现的条形码生成
- 只负责生成，不负责解析
- 主要类

  —BarcodeUtil

  —BarcodeGenerator

  —DefaultConfiguration

```
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;

import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.impl.upcean.EAN13Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;


public class BarCodeTest {

	public static void main(String[] args) {
		String msg = "123456789012";
		String path = "1dcode.png";
		generateFile(msg, path);
	}

	public static void generateFile(String msg, String path) {
		File file = new File(path);
		try {
			Code39Bean bean = new Code39Bean();
			//EAN13Bean bean = new EAN13Bean();

			// dpi精度
			final int dpi = 150;
			// module宽度
			//bean.setModuleWidth(0.2);
			final double width = UnitConv.in2mm(2.0f / dpi);
			bean.setWideFactor(3);
			bean.setModuleWidth(width);
			bean.doQuietZone(false);

			String format = "image/png";
			// 输出到流
			BitmapCanvasProvider canvas = new BitmapCanvasProvider(new FileOutputStream(file), format, dpi,
					BufferedImage.TYPE_BYTE_BINARY, false, 0);

			// 生成条形码
			bean.generateBarcode(canvas, msg);

			// 结束绘制
			canvas.finish();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.DefaultConfiguration;
import org.krysalis.barcode4j.BarcodeGenerator;
import org.krysalis.barcode4j.BarcodeUtil;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.MimeTypes;

public class DataMatrixCodeTest {
	
	public static void main(String[] args) throws Exception {

		BarcodeUtil util = BarcodeUtil.getInstance();
		BarcodeGenerator gen = util.createBarcodeGenerator(buildCfg("datamatrix"));

		OutputStream fout = new FileOutputStream("2dcode.png");
		int resolution = 300;
		BitmapCanvasProvider canvas = new BitmapCanvasProvider(fout, "image/png", resolution,
				BufferedImage.TYPE_BYTE_BINARY, false, 0);

		gen.generateBarcode(canvas, "be the coder");
		canvas.finish();
	}

	private static Configuration buildCfg(String type) {
		DefaultConfiguration cfg = new DefaultConfiguration("barcode");

		// Bar code type
		DefaultConfiguration child = new DefaultConfiguration(type);
		cfg.addChild(child);

		// Human readable text position
		DefaultConfiguration attr = new DefaultConfiguration("human-readable");
//		DefaultConfiguration subAttr = new DefaultConfiguration("placement");
//		subAttr.setValue("bottom");
//		attr.addChild(subAttr);
//		child.addChild(attr);
//		datamatrix code has no human-readable part
//		see http://barcode4j.sourceforge.net/2.1/symbol-datamatrix.html
		
		attr = new DefaultConfiguration("height");
		attr.setValue(50);
		child.addChild(attr);
		attr = new DefaultConfiguration("module-width");
		attr.setValue("0.6");
		child.addChild(attr);
		return cfg;
	}
}
```

### 第六节 Docx简介及解析

#### 1、Docx简介

- Microsoft Office的doc/docx为主要处理对象
- Word2003(包括)之前都是doc，文档格式不公开
- Word2007(包括)之后都是docx，遵循XML路径，文档格式公开
- docx为主要研究对象

  —文字样式

  —图片

  —公式

#### 2、Docx功能和处理

- 常用功能

  —docx解析

  —docx生成
- 处理的第三方库

  —Jacob，COM4J(Windows平台)

  —POI,docx4j,OpenOffice/Libre Office SDK

  —Aspose(收费)

  —一些开源的OpenXML的包

#### 3、POI

- Apache POI

  —Apache出品，必属精品，poi.apache.org

  —可处理docx,xlsx,pptx,visio等office套件

  —纯Java工具包，无需第三方依赖

  —XWPFDocument 整个文档对象

  —XWPFParagraph 段落//以回车来区分

  —XWPFRun 一个片段(字体样式相同的一段)

  —XWPFPicture 图片

  —XWPFTable 表格

### 第七节 表格文件简介及解析

#### 1、xlsx(Excel)

- 与word类似，也分成xls和xlsx
- xlsx以XML为标准，为主要研究对象
- 数据

#### 2、xlsx(Excel)功能和第三方包

- 常见功能

  —解析

  —生成
- 第三方的包

  —POI,JXL(免费)

  —COM4J(Windows平台)

  —Aspose等(收费)

#### 3、POI

- Apache POI

  —XSSFWorkbook 整个文档对象

  —XSSFSheet 单个sheet对象

  —XSSFRow 一行对象

  —XSSFCell 一个单元格对象

  ```
  package xlsx;
  
  import java.io.FileInputStream;
  import java.io.FileOutputStream;
  import java.io.IOException;
  import java.io.InputStream;
  import java.util.Iterator;
  
  import org.apache.poi.xssf.usermodel.XSSFCell;
  import org.apache.poi.xssf.usermodel.XSSFRow;
  import org.apache.poi.xssf.usermodel.XSSFSheet;
  import org.apache.poi.xssf.usermodel.XSSFWorkbook;
  
    public static void readXLSXFile() throws IOException
    {
      InputStream ExcelFileToRead = new FileInputStream("Test.xlsx");
      XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
  
      XSSFSheet sheet = wb.getSheetAt(0);
      XSSFRow row;
      XSSFCell cell;
  
      Iterator rows = sheet.rowIterator();
  
      while (rows.hasNext())
      {
        row = (XSSFRow) rows.next();
        Iterator cells = row.cellIterator();
        while (cells.hasNext())
        {
          cell = (XSSFCell) cells.next();
  
          if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING)
          {
            System.out.print(cell.getStringCellValue() + " ");
          }
          else if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
          {
            System.out.print(cell.getNumericCellValue() + " ");
          }
          else
          {
            // U Can Handel Boolean, Formula, Errors
          }
        }
        System.out.println();
      }
  
    }
  
    public static void writeXLSXFile() throws IOException
    {
  
      String excelFileName = "Test.xlsx";// name of excel file
  
      String sheetName = "Sheet1";// name of sheet
  
      XSSFWorkbook wb = new XSSFWorkbook();
      XSSFSheet sheet = wb.createSheet(sheetName);
  
      // iterating r number of rows
      for (int r = 0; r < 5; r++)
      {
        XSSFRow row = sheet.createRow(r);
  
        // iterating c number of columns
        for (int c = 0; c < 5; c++)
        {
          XSSFCell cell = row.createCell(c);
  
          cell.setCellValue("Cell " + r + " " + c);
        }
      }
  
      FileOutputStream fileOut = new FileOutputStream(excelFileName);
  
      // write this workbook to an Outputstream.
      wb.write(fileOut);
      fileOut.flush();
      fileOut.close();
    }
  
    public static void main(String[] args) throws IOException
    {
      writeXLSFile();
      readXLSFile();
  
      writeXLSXFile();
      readXLSXFile();
    }
  }
  ```

  

#### 4、CSV文件

- 全称：Comma-Seperated Values文件(逗号分隔)

- 广义CSV文件，可以由空格/Tab键/分号/.../完成字段分隔

- 第三方包：Apache Commons CSV

  ```
  package csv;
  
  import java.io.FileReader;
  import java.io.FileWriter;
  import java.io.IOException;
  import java.io.Reader;
  import java.time.LocalDate;
  
  import org.apache.commons.csv.CSVFormat;
  import org.apache.commons.csv.CSVPrinter;
  import org.apache.commons.csv.CSVRecord;
  
  public class CSVTest {
  
  	public static void main(String[] args) throws Exception {
  		readCSVWithIndex();
  		System.out.println("===========华丽丽的分割线1===================");
  		readCSVWithName();
  		System.out.println("===========华丽丽的分割线2===================");
  		writeCSV();
  		System.out.println("write done");
  	}
  	
  	public static void readCSVWithIndex() throws Exception {
  		Reader in = new FileReader("c:/temp/score.csv");
  		Iterable<CSVRecord> records = CSVFormat.EXCEL.parse(in);
  		for (CSVRecord record : records) {
  		    System.out.println(record.get(0)); //0 代表第一列
  		}
  	}
  	
  	public static void readCSVWithName() throws Exception {
  		Reader in = new FileReader("c:/temp/score.csv");
  		Iterable<CSVRecord> records = CSVFormat.RFC4180.withHeader("Name", "Subject", "Score").parse(in);
  		for (CSVRecord record : records) {
  		    System.out.println(record.get("Subject")); 
  		}
  	}
  	
  	public static void writeCSV() throws Exception {
  		try (CSVPrinter printer = new CSVPrinter(new FileWriter("person.csv"), CSVFormat.EXCEL)) {
  		     printer.printRecord("id", "userName", "firstName", "lastName", "birthday");
  		     printer.printRecord(1, "john73", "John", "Doe", LocalDate.of(1973, 9, 15));
  		     printer.println();  //空白行
  		     printer.printRecord(2, "mary", "Mary", "Meyer", LocalDate.of(1985, 3, 29));
  		 } catch (IOException ex) {
  		     ex.printStackTrace();
  		 }
  	}
  }
  ```

### 第八节 PDF简介及解析

#### 1、PDF处理和第三方包

- 常见功能处理

  —解析PDF

  —生成PDF(转化)
- 第三方包

  —Apache PDFBox(免费)

  —iText(收费)

  —XDocReport(将docx转化为pdf)

#### 2、PDFBox

- Apache PDFBox

  —纯Java类库

  —主要功能：创建，提取文本，分割/合并/删除，...

  —PDDocument pdf文档对象

  —PDFTextStripper pdf文本对象

  —PDFMergerUtility 合并工具

#### 3、XDocReport

- XDocReport

  —将docx文档合并输出为其他数据格式(pdf/html/...)

  —PdfConverter

  —基于poi和iText完成