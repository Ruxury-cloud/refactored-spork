## 第七章 Java 数据库编程

### 第一节 数据库和SQL

#### 1、DB

- DB:保存数据的地方

  —数据安全、安全、安全

  —存取效率

  —性价比高

#### 2、DB分类

- DB(文件集合，类似.doc,.docx文件)
- DBMS:Database Management System (类似Office)

  —操纵和管理数据库的软件，可建立、使用和维护

#### 3、表

- 表：table,实体

  —列：列、属性、字段

  —行：记录、元组tuple，数据
- 数据值域：数据的取值范围
- 字段类型

  —int:整数 -2147483648~2147483647，4个字节

  —double：小数，8个字节

  —datetime：时间，7个字节

  —varchar：字符串，可变字节

### 第二节 JDBC基本操作

#### 1、JDBC

- Java和数据库的连接方法

  —Native API(不能跨平台)

  —ODBC/JDBC-ODBC(效率很差，也无法跨平台)

  —JDBC(主流)

#### 2、Java SQL操作类

- 一般数据库发行包都会提供jar包，同时也要注意区分32位和64位(数据库分32/64位，JDK也分32/64位。)

- 连接字符串

  —jdbc:oracle:thin:@127.0.0.1:1521:dbname

  —jdbc:mysql://localhost:3306/mydb

  —jdbc:sqlserver://localhost:1433;DatabaseName=dbname

#### 3、Java连接数据库操作步骤

- 构建连接

  —注册驱动，寻找材质，class.forName("...");

  —确定对岸目标，建桥Connection
- 执行操作

  —Statement(执行者)

  —ResultSet(结果集)
- 释放连接(拆桥) connection.close();

#### 4、Statement

- Statement 执行者类

  —使用executeQuery()执行select语句，赶回结果放在ResultSet

  —使用executeUpdate()执行insert/update/delete，返回修改的行数

  —一个Statement对象一次只能执行一个命令
- ResultSet 结果对象

  —next()判断是否还有下一条记录

  —getInt/getString/getDouble/......

#### 5、注意事项

- ResultSet不能多个做笛卡尔积连接
- ResultSet最好不要超过百条，否则极其影响性能
- ResultSet也不是一口气加载所有的select结果数据
- Connection很昂贵，需要及时close
- Connection所用的jar包和数据库要匹配

```
import java.sql.*;

public class SelectTest {
    public static void main(String[] args){
    	
    	//构建Java和数据库之间的桥梁介质
        try{            
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("注册驱动成功!");
        }catch(ClassNotFoundException e1){
            System.out.println("注册驱动失败!");
            e1.printStackTrace();
            return;
        }
        
        String url="jdbc:mysql://localhost:3306/test";        
        Connection conn = null;
        try {
        	//构建Java和数据库之间的桥梁：URL，用户名，密码
            conn = DriverManager.getConnection(url, "root", "123456");
            
            //构建数据库执行者
            Statement stmt = conn.createStatement(); 
            System.out.println("创建Statement成功！");      
            
            //执行SQL语句并返回结果到ResultSet
            ResultSet rs = stmt.executeQuery("select bookid, bookname, price from t_book order by bookid");
                        
            //开始遍历ResultSet数据
            while(rs.next())
            {
            	System.out.println(rs.getInt(1) + "," + rs.getString(2) + "," + rs.getInt("price"));
            }
            
            rs.close();
            stmt.close();
            
        } catch (SQLException e){
            e.printStackTrace();
        }
        finally
        {
        	try
        	{
        		if(null != conn)
        		{
            		conn.close();
            	}
        	}
        	catch (SQLException e){
                e.printStackTrace();
        	}        	
        }
    }
}
```

### 第三节 JDBC高级操作

#### 1、事务

- 数据库事务，Database Transaction
- 作为单个逻辑工作单元执行的一系列操作，要么完全地执行，要么完全地不执行
- 事务是数据库运行中的逻辑工作单位，由DBMS中的事务管理子系统负责事务的处理

#### 2、JDBC事务

- 关闭自动提交，实现多语句同一事务
- connection.setAutoCommit(false);
- connection.commit();提交事务
- connection.rollback();回滚事务

#### 3、PreparedStatement

- Java提供PreparedStatement，更为安全执行SQL
- 和Statement区别是使用“？”代替字符串拼接
- 使用setXXX(int,Object)的函数来实现对于？的替换
- 提供addBatch批量更新功能

#### 4、ResultSetMetaData

- ResultSet可以用来承载所有的select语句返回的结果集

```
import java.sql.*;

public class ResultSetMetaDataTest {
    public static void main(String[] args){
    	
    	//构建Java和数据库之间的桥梁介质
        try{            
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("注册驱动成功!");
        }catch(ClassNotFoundException e1){
            System.out.println("注册驱动失败!");
            e1.printStackTrace();
            return;
        }
        
        String url="jdbc:mysql://localhost:3306/test";        
        Connection conn = null;
        try {
        	//构建Java和数据库之间的桥梁：URL，用户名，密码
            conn = DriverManager.getConnection(url, "root", "123456");
            
            //构建数据库执行者
            Statement stmt = conn.createStatement(); 
            System.out.println("创建Statement成功！");      
            
            //执行SQL语句并返回结果到ResultSet
            ResultSet rs = stmt.executeQuery("select bookid, bookname, price from t_book order by bookid");
                        
            //获取结果集的元数据
            ResultSetMetaData meta = rs.getMetaData(); 
            int cols = meta.getColumnCount(); 
            for(int i=1;i<=cols;i++)
            {
            	System.out.println(meta.getColumnName(i) + "," + meta.getColumnTypeName(i));
            }
            
            rs.close();
            stmt.close();
            
        } catch (SQLException e){
            e.printStackTrace();
        }
        finally
        {
        	try
        	{
        		if(null != conn)
        		{
            		conn.close();
            	}
        	}
        	catch (SQLException e){
                e.printStackTrace();
        	}        	
        }
    }
}
```

#### 第四节 数据库连接池

#### 1、享元模式

- Connection是Java和数据库两个平行系统的桥梁
- 桥梁构建不易，成本很高，单次使用成本昂贵
- 运用共享技术来实现数据库连接池(享元模式)

  —降低系统中数据库连接Connection对象的数量

  —降低数据库服务器的连接响应消耗

  —提高Connection获取的响应速度
- 享元模式，Flyweight Pattern

  —经典23个设计模式的一种，属于结构型模式

  —一个系统中存在大量的相同的对象，由于这类对象的大量使用，会造成系统内存的耗费，可以使用享元模式来减少系统中对象的数量

#### 2、数据库连接池

- 理解池Pool的概念

  —初始数、最大数、增量、超过时间等参数

- 常用的数据库连接池

  —DBCP(性能较差)

  —C3P0

  —Druid

  
