# 作业提交流程

* 将作业仓库fork到自己的githup上去，在自己的githup的仓库分支上进行操作
* 将自己githup上的此作业仓库的分支clone到本地，修改后push到githup上去
* 作业完成后将作业链接提交到issue下

